/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 04 - Exercício 04 - Diffie-hellman
 *
 *  Instruções
 *  ----------
 *
 *  Este arquivo contém o código que auxiliará no desenvolvimento do
 *  exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *  Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */




/* <<< COMPLETE AQUI >>> */

#include <stdio.h>

int main(){
  long long int goriginal, g, p, A, B, a = 1, b = 1, K, potencia, contador = 1, Ka;
  // g^a = A, g^b = B
  // K = (g ^ a * b) % p

  scanf("%lld %lld %lld %lld", &goriginal, &p, &A, &B);
  g = goriginal;

  if (A==1){
    a = 0;
  }
  if (B==1){
    b = 0;
  }
  
  while (g!=A){
    g *= goriginal;
    a +=1;
    //printf("%d\n", g);
  }
  g = goriginal;
  while (g!=B){
    g *= goriginal;
    b +=1;
    //printf("%d\n", g);
  }

  g = goriginal;
  potencia = a*b;

  // Números estão grandes demais, usar a fórmula do professor.
  
  while (contador<a){
    contador+=1;
    g *= goriginal;
    //printf("g %lld\n", g);
  }

  Ka = g % p;
  K = Ka;
  //printf("Ka %lld\n", Ka);
  contador = 1;
  while (contador<b){
    contador+=1;
    K *= Ka;
    //printf("k %lld\n", K);
  }

  K = K % p;
  
  //printf("a %lld\nb %lld\ng %lld\np %lld\npotencia %lld\n", a, b, g, p, potencia);
  printf("%lld\n", K);
  return(0);
}

