/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: IntroduÃ§Ã£o Ã  ProgramaÃ§Ã£o
 *  Prof. Tiago A. Almeida
 *
 *  Lista 09 - ExercÃ­cio 01 - Base64
 *
 *  InstruÃ§Ãµes
 *  ----------
 *
 *	Este arquivo contÃ©m o cÃ³digo que auxiliarÃ¡ no desenvolvimento do
 *	exercÃ­cio. VocÃª precisarÃ¡ completar as partes requisitadas.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */

/// ---- ATENCAO: NAO ALTERAR DAQUI ---->
#include <stdio.h>
#include <stdlib.h>

#define MAX 2000

int lerCaracteres(char caracteres[]);
void imprimirCaracteres(char caracteres[],int tamCaracteres);
int textParaBin(char text[],int bin[],int tamText);
int textParaBase64(char text[],char base64[],char alfabetoBase64[],int tamText);

int main() {
    int bin[8*MAX];
    char text[MAX], base64[2*MAX];
    char alfabetoBase64[] = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','0','1','2','3','4','5','6','7','8','9','+','/'};
    int qtdCaracteres;
	
    qtdCaracteres = lerCaracteres(text);
	
    qtdCaracteres = textParaBase64(text,base64,alfabetoBase64,qtdCaracteres);
	
    imprimirCaracteres(base64,qtdCaracteres);
	
	return(0);
}
/// <---- ATE AQUI!!! ----


/// ---- APENAS IMPLIMENTE OU COMPLETE AS FUNCOES ABAIXO ---->

int lerCaracteres(char caracteres[]){
  scanf("c", &caracteres[]);
}

//implementar funcao imprimirCaracteres()

//implementar funcao textParaBin()

int textParaBase64(char text[],char base64[],char alfabetoBase64[],int tamText) {
    int bin[MAX];
    int tamBin = textParaBin(text,bin,tamText);
    //completar...
}


