/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 04 - Exercício 03 - Vinte e um
 *
 *  Instruções
 *  ----------
 *
 *	Este arquivo contém o código que auxiliará no desenvolvimento do
 *	exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */

/* <<< COMPLETE AQUI >>> */

#include <stdio.h>

int main(){
	int kirk = 0, spock = 0, kirkadd, spockadd;

	while (kirk < 21 && spock < 21){
		scanf("%d \n %d", &kirkadd, &spockadd);
		kirk += kirkadd;
    spock += spockadd;
    if (spock == 21 & kirk != 21){
		  printf("Spock venceu!\n");
		  printf("Kirk: %d e Spock: %d\n", kirk, spock);
    }
	  else if (kirk == 21 && spock != 21){
		  printf("Kirk venceu!\nKirk: %d e Spock: %d\n", kirk, spock);
    }
	  else if (kirk > 21 && spock < 21){
		  printf("Spock venceu!\nKirk: %d e Spock: %d\n", kirk, spock);
    }
	  else if (spock > 21 && kirk < 21){
		  printf("Kirk venceu!\nKirk: %d e Spock: %d\n", kirk, spock);
    }
	  else if (spock > 21 && kirk > 21){
		  printf("Empate!\nKirk: %d e Spock: %d\n", kirk, spock);
    }
    } 
	return 0;
}
