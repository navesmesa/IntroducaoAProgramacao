/* ================================================================== *
 *  Universidade Federal de São Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 06 - Exercício 1 - Juízes olímpicos
 *
 *  Instruções
 *  ----------
 *
 *  Este arquivo contém o código que auxiliará no desenvolvimento do
 *  exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *  Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */
#include <stdio.h>

/* <<< COMPLETE AQUI >>>*/

int main(){
int j, i;
scanf("%d", &j);
double notas [j], finais[j], media, menor = 5, maior = 5, qtd=0;
  
for (i = 0;i<j;i++){
  scanf("%lf", &notas[i]);
  if (notas[i]<menor){
    menor = notas[i];
  }
  else if (notas[i]>maior){
    maior = notas[i];
  }
  else{
    maior = maior;
    menor = menor;
  }


  //printf("%lf %lf\n", maior, menor);
}
for (i = 0;i<j;i++){
  if (((notas[i] == menor) || (notas[i]==maior)) && qtd<2){
    finais[i] = 0;
    qtd++;
  }
  else{
   finais[i] = notas[i];
  }
  }  
  //printf("finais %lf %lf %lf %lf %lf\n", finais[0], finais[1], finais[2], finais[3], finais[4]);
for (i = 0;i<j;i++){
  media += finais[i];
  //printf("Media %.2lf\n", media);
  }
  media/=(j-2);
  printf("%.2lf\n", media);

  return 0;
}