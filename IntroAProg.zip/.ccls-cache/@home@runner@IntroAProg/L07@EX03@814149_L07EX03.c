#include <stdio.h>

int main(){
  int x, y, i = 0, j = 0, prateleira, contador = 0, troca = 0, trocax, trocay;
  char comando;
  
  scanf("%d %d", &x, &y);

  int matriz[x][y];

  for (i = 0; i<x;i++){
    for (j=0;j<y;j++){
      scanf("%d", &matriz[i][j]);
    }
  }

  /*for (i = 0; i<x;i++){
    for (j=0;j<y;j++){
      printf("%d ", matriz[i][j]);
    }
    printf("\n");
  }*/
  
  while(1){
    scanf("%c", &comando);
    if (comando == 'S'){
      break;
    }
    if (comando=='I'){
      scanf("%d", &prateleira);
      contador = 0;

      for (j = 0; j<y;j++){
        if(matriz[prateleira][j] == 0){
          contador++;
        }
      }

      if (contador == 0){
        printf("Prateleira cheia!\n");
      }

      else{
        printf("Coluna(s): ");
        for (j = 0; j<y;j++){
        if(matriz[prateleira][j] == 0){
          printf("%d ", j+1);
        }
      }
        printf("\n");
      }
      
    }
    if (comando=='V'){
      contador = 0;
      for(i = 0; i<x; i++){
        for (j=0;j<y;j++){
          if (matriz[i][j]==0){
            contador++;
          }
        }
      }
      if (contador!=0){
        printf("Ha espaco disponivel!\n");
      }
      else{
        printf("Estante cheia!\n");
      }
    }
    if (comando=='T'){
      scanf("%d %d", &i, &j);
      scanf("%d %d", &trocax, &trocay);

      troca = matriz[i][j];
      matriz[i][j] = matriz[trocax][trocay];
      matriz[trocax][trocay] = troca;

    for (i = 0; i<x;i++){
      for (j=0;j<y;j++){
        printf("%d ", matriz[i][j]);
      }
      printf("\n");
    }
      
    }
    if (comando=='E'){
      scanf("%d %d", &i, &j);

      if (matriz[i][j] == 0){
        printf("Livro emprestado!\n");
      }
      else{
        matriz[i][j] = 0;
      }

    }
    
  }

  
  return 0;
}