#include <stdio.h>

int main(){

    int num, x, y, troca;
    float mediana = 0;
    scanf("%d", &num);  
    int valores[num];
    for(x=0;x<num;x++){
      scanf("%d", &valores[x]);
    }
    for(x = 0; x < num - 1; x++){       
        for(y = 0; y < num - x - 1; y++){          
            if(valores[y] > valores[y + 1]){               
                troca = valores[y];
                valores[y] = valores[y + 1];
                valores[y + 1] = troca;
            }
        }
    }

    printf("A\n");

    for(x = 0; x < num; x++){

        printf("%d ", valores[x]);

    }
    printf("\n");

   if (num%2!=0){
     mediana = (float)valores[num/2];
   }
  else if (num%2==0){
    mediana = ((float)(valores[num/2] + valores[(num/2)-1]))/2;
  }

    printf("Med %f", mediana);
  
    return 0;
}