#include <stdio.h>

int main(){
  int n_original, n_ao_contrario;
  double n_a_adicionar = 0, n = 0;

  scanf("%d", &n_original);

  n = n_original;
  
  while(n>0) {
    n_a_adicionar = (int)n%10;
    n = (n/10);
    n_ao_contrario *= 10;
    n_ao_contrario += (int)n_a_adicionar;
    n = (int)n;
}

  if (n_ao_contrario == n_original){
  printf("%d eh um palindromo.\n", n_original);
  }
  if (n_ao_contrario != n_original){
  printf("%d nao eh um palindromo.\n", n_original);
  }
  return(0);
}