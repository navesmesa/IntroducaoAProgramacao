/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 02 - Exercício 05 - Eleições
 *
 *  Instruções
 *  ----------
 *
 *	Este arquivo contém o código que auxiliará no desenvolvimento do
 *	exercício. Você precisará completar as partes requisitadas.
 *
 *  OBS: Não utilize conceitos ainda não aprendidos em aula, todos os
 *  exercícios podem ser resolvidos apenas com o conteúdo já passado.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */

/* <<< COMPLETE AQUI >>> */


#include <stdio.h>

int main(){
  int x, y, z, brancos, nulos, totais;
  float perx = 0, pery = 0, perz = 0, perbrancos = 0, pernulos = 0;

  scanf("%d %d %d %d %d", &x, &y, &z, &brancos, &nulos);

  totais = x + y + z;
  perx = ((float)x * 100)/totais;
  pery = ((float)y * 100)/totais;
  perz = ((float)z * 100)/totais;
  perbrancos = ((float)brancos) * 100/(totais + brancos + nulos);
  pernulos = ((float)nulos) * 100/(totais + brancos + nulos);

  printf("x : %.2f%%\n", perx);
  printf("y : %.2f%%\n", pery);
  printf("z : %.2f%%\n", perz);
  printf("nulos : %.2f%%\n", perbrancos);
  printf("brancos : %.2f%%\n", pernulos);
  

  return(0);
}