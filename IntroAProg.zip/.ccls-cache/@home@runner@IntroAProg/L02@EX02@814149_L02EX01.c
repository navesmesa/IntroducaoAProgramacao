/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 02 - Exercício 02 - Gasto de energia
 *
 *  Instruções
 *  ----------
 *
 *	Este arquivo contém o código que auxiliará no desenvolvimento do
 *	exercício. Você precisará completar as partes requisitadas.
 *
 *  OBS: Não utilize conceitos ainda não aprendidos em aula, todos os
 *  exercícios podem ser resolvidos apenas com o conteúdo já passado.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */

/* <<< COMPLETE AQUI >>> */

/* kwh = 0,525 * 1000 = wh = 525

*/

#include <stdio.h>
#define GELADEIRA 0.130
#define MICROONDAS 0.200
#define CHUVEIRO 0.350
#define ASPIRADOR 0.100
#define COMPUTADOR 0.180

int main(){
  float usogel, usomicro, usochu, usoasp, usocomp, custo = 0;

  scanf("%f", &usogel);
  scanf("%f", &usomicro);
  scanf("%f", &usochu);
  scanf("%f", &usoasp);
  scanf("%f", &usocomp);

  custo = (usogel * GELADEIRA) + (usomicro * MICROONDAS) + (usochu * CHUVEIRO) + (usoasp * ASPIRADOR) + (usocomp * COMPUTADOR);

  printf("R$%.2f", custo);
  return(0);
}