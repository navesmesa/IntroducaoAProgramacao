/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 05 - Exercício 02 - Cifra de Cesar
 *
 *  Instruções
 *  ----------
 *
 *	Este arquivo contém o código que auxiliará no desenvolvimento do
 *	exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */

#include <stdio.h>

/* <<< COMPLETE AQUI >>> */


int main(){
	int sum, qtdcarac, contador, multiplo;
	char DecCod, carac;

	scanf(" %c ", &DecCod);
	scanf(" %d \n %d ", &sum, &qtdcarac);

  multiplo = 0;
  if (sum>26){
  while (multiplo<sum){
    multiplo+=26;
  }
    multiplo-=26;
  //printf("mul %d\n", multiplo);
   sum -= multiplo;
  //printf("sum %d\n", sum);
    }
	if (DecCod == 68){	
		for(contador=1;qtdcarac>=contador;contador++){
		scanf(" %c ", &carac);
    if ((carac-sum)<97){
      carac+=26;      
    }
		printf("%c", carac-sum);
		}
    printf("\n");
	}	
	else if (DecCod == 67){
	for(contador=1;qtdcarac>=contador;contador++){
	scanf(" %c ", &carac);
    if ((carac+sum)>122){
      carac-=26;      
    }
	printf("%c", carac+sum);
    
		}
    
    printf("\n");
	}

return 0;
}