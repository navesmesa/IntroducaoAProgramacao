/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 01 - Exercício 02 - Calculadora
 *
 *  Instruções
 *  ----------
 *
 *	Este arquivo contém o código que auxiliará no desenvolvimento do
 *	exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */

/* <<< COMPLETE AQUI >>> */

/* Entradas: N1 e N2
  Saídas: n1 + n2, n1 - n2, n2 - n1, n1 * n2, n2 / n1, n1 / n2, quociente inteiro da div1 e div2, resto da div1 e div2, soma dos resultados de todas*/

#include <stdio.h>

int main(){ 
  
  int n1, n2;
  float somaN, sub1, sub2, mult, div1, div2, resto1, resto2, somaOp;

  scanf("%d", &n1);
  scanf("%d", &n2);

  somaN =  n1 + n2;

  printf("%f", somaN);
  
  return (0);}