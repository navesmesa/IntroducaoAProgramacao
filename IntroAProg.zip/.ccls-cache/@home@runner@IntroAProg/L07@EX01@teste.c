#include <stdio.h>

int main(){
  int tamanho, i, j;
  int contadorT = 0, contadorM = 0, contadorL = 0, contadorW = 0;
  scanf("%d", &tamanho);

  char tabela [tamanho][tamanho];

  for (i=0;i<tamanho;i++){
    for (j=0;j<tamanho;j++){
      tabela[i][j] = '0';
    
    }
  }
  
  int valori, valorj;

  scanf("%d %d", &valori, &valorj);
//M
  for(j=0;j<tamanho;j++){
    tabela[valori][j] = 'M';
  }
  for(i=0;i<tamanho;i++){
    tabela[i][valorj] = 'M';
  }
  for (i=0;i<tamanho;i++){
    for (j=0;j<tamanho;j++){
      switch (tabela[i][j]){
        case 'T':
          contadorT += 1;
          break;
        case 'L':
          contadorL += 1;
          break;
        case 'M':
          contadorM += 1;
          break;
        case 'W':
          contadorW += 1;
          break;
      }
    }
  }

  printf("M %d\nL %d\nW %d\nT %d\n", contadorM, contadorL, contadorW, contadorT);

  contadorT = 0, contadorM = 0, contadorL = 0, contadorW = 0;
  
//L

  scanf("%d %d", &valori, &valorj);

  while (tabela[valori][valorj] != '0' || (valori>=tamanho) || (valorj>=tamanho) ){
    printf("Posicao Invalida!\n");
    scanf("%d %d", &valori, &valorj);
  }

    for(j=0;j<tamanho;j++){
    tabela[valori][j] = 'L';
  }
  for(i=0;i<tamanho;i++){
    tabela[i][valorj] = 'L';
  }
  for (i=0;i<tamanho;i++){
    for (j=0;j<tamanho;j++){
      switch (tabela[i][j]){
        case 'T':
          contadorT += 1;
          break;
        case 'L':
          contadorL += 1;
          break;
        case 'M':
          contadorM += 1;
          break;
        case 'W':
          contadorW += 1;
          break;
      }
    }
  }

  printf("M %d\nL %d\nW %d\nT %d\n", contadorM, contadorL, contadorW, contadorT);

  contadorT = 0, contadorM = 0, contadorL = 0, contadorW = 0;
  
// W

    scanf("%d %d", &valori, &valorj);

  while (tabela[valori][valorj] != '0'){
    printf("Posicao Invalida!\n");
    scanf("%d %d", &valori, &valorj);
  }

    for(j=0;j<tamanho;j++){
    tabela[valori][j] = 'W';
  }
  for(i=0;i<tamanho;i++){
    tabela[i][valorj] = 'W';
  }
  for (i=0;i<tamanho;i++){
    for (j=0;j<tamanho;j++){
      switch (tabela[i][j]){
        case 'T':
          contadorT += 1;
          break;
        case 'L':
          contadorL += 1;
          break;
        case 'M':
          contadorM += 1;
          break;
        case 'W':
          contadorW += 1;
          break;
      }
    }
  }

  printf("M %d\nL %d\nW %d\nT %d\n", contadorM, contadorL, contadorW, contadorT);

  contadorT = 0, contadorM = 0, contadorL = 0, contadorW = 0;

// T

scanf("%d %d", &valori, &valorj);

  while (tabela[valori][valorj] != '0'){
    printf("Posicao Invalida!\n");
    scanf("%d %d", &valori, &valorj);
  }

    for(j=0;j<tamanho;j++){
    tabela[valori][j] = 'T';
  }
  for(i=0;i<tamanho;i++){
    tabela[i][valorj] = 'T';
  }

  for (i=0;i<tamanho;i++){
    for (j=0;j<tamanho;j++){
      switch (tabela[i][j]){
        case 'T':
          contadorT += 1;
          break;
        case 'L':
          contadorL += 1;
          break;
        case 'M':
          contadorM += 1;
          break;
        case 'W':
          contadorW += 1;
          break;
      }
    }
  }

  printf("M %d\nL %d\nW %d\nT %d\n", contadorM, contadorL, contadorW, contadorT);

  if (contadorM > contadorL && contadorM > contadorW && contadorM > contadorT){
    printf("Marcelo venceu!\n");
  }
  if (contadorL > contadorM && contadorL > contadorW && contadorL > contadorT){
    printf("Luis venceu!\n");
  }
  if (contadorW > contadorM && contadorW > contadorL && contadorW > contadorT){
    printf("Waldo venceu!\n");
  }
  if (contadorT > contadorM && contadorT > contadorW && contadorT > contadorL){
    printf("Thomas venceu!\n");
  }
  
  return 0;
}