/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 01 - Exercício 06 - Horário ônibus
 *
 *  Instruções
 *  ----------
 *
 *	Este arquivo contém o código que auxiliará no desenvolvimento do
 *	exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */

/* <<< COMPLETE AQUI >>> */


#include <stdio.h>

int main(){
  int min, hora, tempoate, horaac, minutoac, qtdhr;

  scanf("%d", &tempoate);
  scanf("%d", &hora);
  scanf("%d", &min);

  if (tempoate > 300 || tempoate <= 0 || min>=60){
    return(0);
  }
  
  qtdhr = tempoate/60;
  tempoate = tempoate - 60 * qtdhr;

  if (tempoate > min){
    minutoac = 60 + min - tempoate;
    qtdhr+=1;
  }

  else{
    minutoac = min - tempoate;
  }

  if (qtdhr >= hora){
    horaac = hora - qtdhr;
    horaac+=24;
  } 
  else{
    horaac = hora - qtdhr;
  }

  printf("%d:%02d\n", horaac, minutoac);
    
  return(0);
}