#include <stdio.h>

/*	Cifra de césar
	


*/


int main(){
	int sum, qtdcarac, contador;
	char DecCod, carac;

	scanf("%c", &DecCod);
	scanf("%d %d", &sum, &carac);

	if (DecCod == "D"){	
		for(contador=1;carac>=contador;contador++){
		scanf("%c", &carac);
		printf("%c\n", carac-sum);
		}
	}	
	else if (DecCod == "C"){
	for(contador=1;carac>=contador;contador++){
	scanf("%c", &carac);
	printf("%c\n", carac+sum);
		}
	}

return 0;
}