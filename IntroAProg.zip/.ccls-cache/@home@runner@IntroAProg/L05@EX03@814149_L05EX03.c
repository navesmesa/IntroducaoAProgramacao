/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 05 - Exercício 03 - XCONtra
 *
 *  Instruções
 *  ----------
 *
 *	Este arquivo contém o código que auxiliará no desenvolvimento do
 *	exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */


/* <<< COMPLETE AQUI >>> */

#include <stdio.h>

int main(){
  int qtdmensagem, qtdsimbolos, qtdex=0, qtd0=0, qtdponto = 0, qtdbar = 0, qtdoriginal;
  float mediaex, mediaponto, mediabar;
  char carac;
  scanf("%d", &qtdmensagem);

  
  while(qtdmensagem!=0){
      qtdsimbolos=qtdoriginal;
      qtdex=0, qtd0=0, qtdponto = 0, qtdbar = 0;
      scanf("%d", &qtdsimbolos);
      qtdoriginal = qtdsimbolos;
      //printf("qtdmens %d\n", qtdmensagem);
      //printf("qtdsimb %d\n", qtdsimbolos);
    while(qtdsimbolos!=0){
      scanf("%c", &carac);
      
      switch (carac){
        case 33:
          qtdex+=1;
          qtd0=0;
          break;
        case 46:
          qtdponto+=1;
          qtd0=0;
          break;
        case 47:
          qtdbar +=1;
          qtd0=0;
          break; 
        case 48:
          qtd0+=1;
          break;
      } 
        if(qtd0==3){
        break;
      }
        else if(qtd0!=0 || qtdbar!=0 || qtdex!=0 || qtdponto!=0){
        //printf("qt! %d qt0 %d qt/ %d qt. %d\n", qtdex, qtd0, qtdbar, qtdponto);
        qtdsimbolos-=1;
        }
     }
      if(qtd0!=3){
      mediaex = (((float)qtdex * 100) / qtdoriginal);
      mediaponto = (((float)qtdponto * 100) / qtdoriginal);
      mediabar = (((float)qtdbar * 100) / qtdoriginal);
      printf("RELATORIO:\n!: %.2f%%\n.: %.2f%%\n/: %.2f%%\n", mediaex, mediaponto, mediabar);
      }
      else{
        printf("Invasao Iminente!\n");
      }
      qtdmensagem-=1;
    }
  return 0;
}