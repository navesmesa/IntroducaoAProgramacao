/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida e Jurandy Almeida
 *
 *  Lista 03 - Exercício 04 - Baka-gan
 *
 *  Instruções
 *  ----------
 *
 *	Este arquivo contém o código que auxiliará no desenvolvimento do
 *	exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */

/* <<< COMPLETE AQUI >>> */


#include <stdio.h>

int main(){
  int poder1, poder2, poder3, poderF, poderA, poderT, poderV, dobra1, dobra2, dobra3;
  char tipo1, tipo2, tipo3, elementof;

  scanf("%d %c %d %c %d %c\n%d %d %d %d\n %c", &poder1, &tipo1, &poder2, &tipo2, &poder3, &tipo3, &poderF, &poderA, &poderT, &poderV, &elementof);

  if (tipo1 == elementof){
    dobra1 = 2;
  }
  if (tipo1 != elementof){
    dobra1 = 1;
  }
  switch(tipo1){
    case 'F':
      poder1 = poder1 + (poderF * dobra1);
      break;
    case 'A':
      poder1 = poder1 + (poderA * dobra1);
      break;
    case 'T':
      poder1 = poder1 + (poderT * dobra1);
      break;
    case 'V':
      poder1 = poder1 + (poderV * dobra1);
      break;
    default:
      return 0;
    }
  if (tipo2 == elementof){
    dobra2 = 2;
  }
  if (tipo2 != elementof){
    dobra2 = 1;
  }
  switch(tipo2){
    case 'F':
      poder2 = poder2 + (poderF * dobra2);
      break;
    case 'A':
      poder2 = poder2 + (poderA * dobra2);
      break;
    case 'T':
      poder2 = poder2 + (poderT * dobra2);
      break;
    case 'V':
      poder2 = poder2 + (poderV * dobra2);
      break;
    default:
      return 0;
    }

  if (tipo3 == elementof){
    dobra3 = 2;
  }
  if (tipo3 != elementof){
    dobra3 = 1;
  }
  switch(tipo3){
    case 'F':
      poder3 = poder3 + (poderF * dobra3);
      break;
    case 'A':
      poder3 = poder3 + (poderA * dobra3);
      break;
    case 'T':
      poder3 = poder3 + (poderT * dobra3);
      break;
    case 'V':
      poder3 = poder3 + (poderV * dobra3);
      break;
    default:
      return 0;
    }
  
  if (poder1 >= poder2 && poder1>=poder3){
    printf("Jogador 1 venceu!\n");
    printf("%d\n", poder1);
  }
  else if (poder2 >= poder1 && poder2 >= poder3){
    printf("Jogador 2 venceu!\n");
    printf("%d\n", poder2);
  }
  else if (poder3 >= poder2 && poder3 >= poder1){
    printf("Jogador 3 venceu!\n");
    printf("%d\n", poder3);
  }
  

  return 0;
}