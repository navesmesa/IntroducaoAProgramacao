/*
Problemas: 
-pegar cada uma das char
-verificar as condições
-printar uma saída dependendo da condição
*/


#include <stdio.h>

int main(){
  char[6]

  
  
  return (0);
}