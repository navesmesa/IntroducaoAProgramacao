/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 01 - Exercício 04 - Código Steam
 *
 *  Instruções
 *  ----------
 *
 *	Este arquivo contém o código que auxiliará no desenvolvimento do
 *	exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */

/* <<< COMPLETE AQUI >>> */

#include <stdio.h>

int main(){

  int dia, soma, sub, mult, posicao;
  char letra1, letra2, letra3, letra4;
  scanf("%d", &dia);
  scanf(" %c%c%c%c", &letra1, &letra2, &letra3, &letra4);
  
  soma = dia + letra1;
  sub = letra2 - dia;
  mult = dia * letra3;
  posicao = letra4 - 64;

  printf("%d\n", soma);
  printf("%d\n", sub);
  printf("%d\n", mult);
  printf("%d\n", posicao);
  
  return(0);
}