/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 05 - Exercício 04 - Conversor de bases númericas
 *
 *  Instruções
 *  ----------
 *
 *	Este arquivo contém o código que auxiliará no desenvolvimento do
 *	exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */

#include <stdio.h>

/* <<< COMPLETE AQUI >>> */

int main(){
  int opcoes, bin = 0, binscan = 0, num, resto, multiplo10=1, multiplo2=1, valor = 0, inteiro = 0, contador = 1, binvertido;
  while(1){
    scanf("%d", &opcoes);
    if (opcoes == 1){
      for(scanf("%d", &binscan), contador = 1;binscan!=-1;scanf("%d", &binscan),contador*=10){
        bin += binscan * contador;
        //printf("bin %d\n", bin);
      }
        //printf("bin %d\n", bin);
        for (multiplo2 = 1, multiplo10 = 1, valor =0,inteiro=0;bin!=0;multiplo2=1, multiplo10=1, valor =0){
          while ((bin/multiplo10)>1){
            multiplo10*=10;
            multiplo2*=2;
          }
          //printf("bin %d\n", bin);
          //printf("Multiplo %d\n", multiplo10);
          //printf("Potencia %d\n", multiplo2);
          valor = bin/multiplo10;
          bin-=multiplo10;
          valor*=multiplo2;
          inteiro +=valor;
        }
        printf("%d\n", inteiro);
      }
      
    else if (opcoes == 2){
      scanf("%d", &num);
      for (;num!=0;num/=2){
        resto = num%2;
        printf("%d", resto);
      }
      printf("\n");
    }
    else if (opcoes == 0){
      return 0;
    }
  }
  
  return 0;
}