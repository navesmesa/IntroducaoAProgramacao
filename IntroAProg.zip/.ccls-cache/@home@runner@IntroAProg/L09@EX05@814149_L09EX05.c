/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 09 - Exercício 05 - Truco paulista
 *
 *  Instruções
 *  ----------
 *
 *	Este arquivo contém o código que auxiliará no desenvolvimento do
 *	exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA:
 *  Nome:
 *
 * ================================================================== */

/// ---- ATENCAO: NAO ALTERAR DAQUI ---->
#include <stdio.h>

#define RODADA1 	"(Time 1 venceu a rodada)\n"
#define RODADA2 	"(Time 2 venceu a rodada)\n"
#define EMPATE 		"(Rodada empatada)\n"
#define GANHOU1 	"Time 1 ganhou a mao!\n"
#define GANHOU2 	"Time 2 ganhou a mao!\n"
#define EMPATEmao 	"Mao empatada!\n"

typedef struct {
  char naipe;
  char valor;
}carta;

void receberCartas(carta v[]);
int maiorNaipe(char n1, char n2);
int checarGanhador(carta c1, carta c2, char manilha);

int main(){
	carta cartas[4], vencedor;
	char manilha;
	scanf(" %c", &manilha);
	
	int g1, g2, round, p1 = 0, p2 = 0, draw = 0, aux = 0;

	while (p1 < 2 && p2 < 2 && draw < 3) {
	    receberCartas(cartas);
	    g1 = checarGanhador(cartas[0], cartas[2], manilha);
	    g2 = checarGanhador(cartas[1], cartas[3], manilha);

	    if (g1 != 0 && g2 != 0)
			round = checarGanhador(cartas[1-g1], cartas[2-g2], manilha);
	    else if (g1 == 0 && g2 != 0)
			round = checarGanhador(cartas[0], cartas[2-g2], manilha);
	    else if (g1 != 0 && g2 == 0)
			round = checarGanhador(cartas[1-g1], cartas[1], manilha);
	    else
			round = checarGanhador(cartas[0], cartas[1], manilha);

    
		if (round == 1){
			if (aux == 0)
				aux = 1;

			printf("(Time 1 venceu a rodada)\n");
			p1 += 1;
		} 
		else if (round == -1){
			if (aux == 0)
				aux = -1;

			printf("(Time 2 venceu a rodada)\n");
			p2 += 1;
		}
    	else{
			printf("(Rodada empatada)\n");
			draw += 1;
		}

		if (draw > 0 && ((p1 != 0) || (p2 != 0))){
			if (aux == 1){
				printf("Time 1 ganhou a mao!\n");
				return (0);        
			}
			else if(aux == -1){
				printf("Time 2 ganhou a mao!\n");
				return (0);
			}
			else if (p1 > p2){
				printf("Time 1 ganhou a mao!\n");
				return (0);
			}
			else if (p1 < p2){
				printf("Time 2 ganhou a mao!\n");
				return (0);
			}
			else {
				printf("Mao empatada!\n");
				return (0);
			}
    	}

	}

	if (p1 > p2)
		printf("Time 1 ganhou a mao!\n");
	else if(p1 < p2)
		printf("Time 2 ganhou a mao!\n");
	else
		printf("Mao empatada!\n");

	return (0);
} /// <---- ATE AQUI!!! ----


/// ---- APENAS IMPLIMENTE AS FUNCOES DAQUI PRA BAIXO

/* <<< COMPLETE AQUI >>> */
void receberCartas(carta v[]){
  int i = 0;
  for (i = 0; i < 4; i++){
    scanf(" %c %c", &v[i].valor, &v[i].naipe);
  }
}
int maiorNaipe(char n1, char n2){
  int valor1 = 0, valor2 = 0, maiorvalor;
  switch (n1){
    case 'P': valor1 = 4; break;
    case 'C': valor1 = 3; break;
    case 'E': valor1 = 2; break;
    case 'O': valor1 = 1; break;
  }
  switch (n2){
    case 'P': valor2 = 4; break;
    case 'C': valor2 = 3; break;
    case 'E': valor2 = 2; break;
    case 'O': valor2 = 1; break;
  }
  if (valor1 > valor2){
    maiorvalor = 1;
  }
  else{
    maiorvalor = -1;
  }
  return maiorvalor;
}
int checarGanhador(carta c1, carta c2, char manilha){
  int valor1 = 0, valor2 = 0, retorno = 0;
  
  if (c1.valor == manilha && c2.valor == manilha){
    retorno = maiorNaipe(c1.naipe, c2.naipe);
    return retorno;
  }
  else if (c1.valor == manilha && c2.valor != manilha){
    retorno = 1;
    return retorno;
  }
  else if (c2.valor == manilha && c1.valor != manilha){
    retorno = -1;
    return retorno;
  }
  else if (c2.valor != manilha && c1.valor != manilha){
    switch (c1.valor){
    case '3': valor1 = 10; break;
    case '2': valor1 = 9; break;
    case 'A': valor1 = 8; break;
    case 'K': valor1 = 7; break;
    case 'J': valor1 = 6; break;
    case 'Q': valor1 = 5; break;
    case '7': valor1 = 4; break;
    case '6': valor1 = 3; break;
    case '5': valor1 = 2; break;
    case '4': valor1 = 1; break;
  }
    switch (c2.valor){
    case '3': valor2 = 10; break;
    case '2': valor2 = 9; break;
    case 'A': valor2 = 8; break;
    case 'K': valor2 = 7; break;
    case 'J': valor2 = 6; break;
    case 'Q': valor2 = 5; break;
    case '7': valor2 = 4; break;
    case '6': valor2 = 3; break;
    case '5': valor2 = 2; break;
    case '4': valor2 = 1; break;
  }
  }
  if (valor1 > valor2){
    retorno = 1;
  }
  else if (valor1 == valor2){
    retorno = 0;
  }
  else{
    retorno = -1;
  }
  //printf("v1 %d v2 %d ret %d\n", valor1, valor2, retorno);
  return retorno;
}