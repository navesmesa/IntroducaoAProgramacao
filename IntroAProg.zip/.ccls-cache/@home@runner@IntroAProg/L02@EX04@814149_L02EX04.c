
/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 02 - Exercício 04 - Conversor de alturas
 *
 *  Instruções
 *  ----------
 *
 *	Este arquivo contém o código que auxiliará no desenvolvimento do
 *	exercício. Você precisará completar as partes requisitadas.
 *
 *  OBS: Não utilize conceitos ainda não aprendidos em aula, todos os
 *  exercícios podem ser resolvidos apenas com o conteúdo já passado.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */

/* <<< COMPLETE AQUI >>> */

#include <stdio.h> 
#define CONVERTEPES 3.28084

int main(){
  int cm;
  float mt, pes, pol;
  scanf("%d", &cm);

  mt = (float)cm/100;
  pes = mt*CONVERTEPES;
  pol = (pes - (int)pes) * 12;
  
  printf("%.2f\n%d\n%.2f\n", mt, (int)pes, pol);

  return(0);
}