/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 10 - Exercício 03 - Os Estranhos
 *
 *  Instruções
 *  ----------
 *
 *	Este arquivo contém o código que auxiliará no desenvolvimento do
 *	exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */

/// ---- ATENCAO: NAO ALTERAR DAQUI ---->
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAXTEXTO    500
#define MAIUSCULA   1
#define MINUSCULA   0
#define VERDADEIRO  1
#define FALSO       0

// prototipos das funcoes
int calculaTamanho(char texto[]); 
int incial(char texto[]); 
int palindromo(char texto[]); 
int vogalDistinta(char texto[]); 
int senhaValida(char texto[]); 
void imprimeEstatistica(char texto[]); 

int main() {
    char texto[MAXTEXTO];

    scanf(" %[^\n]",texto);

    int valida = senhaValida(texto);

    if (valida)
        printf("Autorizado!\n");
    else
        printf("Bloqueado!\n");

    imprimeEstatistica(texto);

    return (0);
}
/// <---- ATE AQUI!!! ----


/// ---- APENAS IMPLEMENTE OU COMPLETE AS FUNCOES ABAIXO ---->

// retorna quantidade de palavras na string (delimitadas por espaços)
int calculaTamanho(char texto[]) {
  int i, contador = 0;

  for(i = 0; texto[i]!= '\0'; i++){
    if (texto[i] == '\0'){
      return contador + 1;
      break;
    }
    else if (texto[i] == ' '){
      contador++;
      //printf("%c\n", texto[i]);
    }
  }

  return contador + 1;
}

// retorna MAIUSCULA ou MINUSCULA dependendo da primeira letra da primeira palavra
int incial(char texto[]) {
  int v;
  char letra;

  letra = texto[0];
    
  if (islower(letra)){
    v = 0;
  }
  else{
    v = 1;
  }

  return v;
  
}

// retorna VERDADEIRO se palindromo e FALSO se nao
int palindromo(char texto[]) {
  int i, v;
  int j = 0;

   for (i=0; i < strlen(texto); i++){
      if (isalpha(texto[i])){
        texto[j] = texto[i];
        j++;
        }
    }
    for (i=0; i < strlen(texto); i++){
        texto[i] = tolower(texto[i]);
    }

    for (i=0;i < strlen(texto);i++){
        if (texto[i] != texto[strlen(texto)-1-i]){
            v = 0;
            return v;
        }
    }
  v = 1;
  return v;
}

// retorna numero total de vogais distintas
int vogalDistinta(char texto[]){
  int i, contador = 0, j = 0;
  char anteriores[10];

  for (i = 0; texto[i]!= '\0'; i++){
    texto[i] = tolower(texto[i]);
  }
  
  for(i = 0; texto[i] != '\0'; i++){
    if (texto[i] == '\0'){
      return contador;
      break;
    }
    else if ((texto[i] == 'a' || texto[i] == 'e' || texto[i] == 'o' || texto[i] == 'i'|| texto[i] == 'u' || texto[i] == 'A' || texto[i] == 'E' || texto[i] == 'O' || texto[i] == 'I'|| texto[i] == 'U') && texto[i] != anteriores[0] && texto[i] != anteriores[1] && texto[i] != anteriores[2] && texto[i] != anteriores[3] && texto[i] != anteriores[4] && texto[i] != anteriores[5] && texto[i] != anteriores[6] && texto[i] != anteriores[7] && texto[i] != anteriores[8] && texto[i] != anteriores[9] ){
      contador++;
      anteriores[j] = texto[i];
      j++;
      //printf("%c\n", texto[i]);
    }
  }
  return contador;
}

// retorna VERDADEIRO se valida (creterios no pdf) ou FALSO se nao
int senhaValida(char texto[]) {
  int palin, inicial, vogal, tamanho;

  char textoriginal[MAXTEXTO];
  int i;

  for(i = 0; texto[i] != '\0'; i++){
    textoriginal[i] = texto[i];
  }
  textoriginal[i+1] = '\0';

  palin = palindromo(textoriginal);
  inicial = incial(textoriginal);
  vogal = vogalDistinta(textoriginal);
  tamanho = calculaTamanho(textoriginal);

  if (palin == 1 && inicial == 1 && vogal >= 2 && tamanho >= 10){
    return 1;
  }
  else{
    return 0;
  }
}

// imprime o texto de [ ESTATISTICA ]
void imprimeEstatistica(char texto[]) {
    printf("[ ESTATISTICA ]\n");
    int palin, inicial, vogal, tamanho;

    inicial = incial(texto);
    tamanho = calculaTamanho(texto);
    palin = palindromo(texto);
    vogal = vogalDistinta(texto);

    printf("Tamanho: %d\n", tamanho);
    if (inicial == 1){
      printf("Inicio: maiuscula\n");
    }
    else if(inicial == 0){
      printf("Inicio: minuscula\n");
    }
    printf("Vogais: %d\n", vogal);
    if (palin == 1){
      printf("Palindromo: sim\n");
    }
    else if(palin != 1){
      printf("Palindromo: nao\n");
    }

  
}