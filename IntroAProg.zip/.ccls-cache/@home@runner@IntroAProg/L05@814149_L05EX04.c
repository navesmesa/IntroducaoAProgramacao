/*
Passos:

Opções: 1 (binário-decimal), 2 (decimal-binário), 0 (sair do programa)

1 - binário para decimal

	- ver a quantidade e elevar de acordo com a posição, ex: 101110

	float(101110)/10 enquanto a div for maior que 0, dividir por 10 * n
	1,01110, int nisso = 1 * 2^n (n = 6)
	float * 10 = 0,1110 int nisso = 0 * 2 ^ n -1
	1,110 = 1 ^ 2 ^ n-2
	1,10 = 1 ^2 n-3
	1,0 = 1, 2^n-4
	0,0 = 1,2^ n-5
	

2 - decimal para binário:
	scanf num
	while num!=0
	bin=num%2
	printf bin
	num/2


*/

#include <stdio.h>

int main(){
  int num, numscan;

  return 0;
}