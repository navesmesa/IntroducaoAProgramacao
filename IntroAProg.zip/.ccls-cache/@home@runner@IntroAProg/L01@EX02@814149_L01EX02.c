/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 01 - Exercício 02 - Calculadora
 *
 *  Instruções
 *  ----------
 *
 *	Este arquivo contém o código que auxiliará no desenvolvimento do
 *	exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */

/* <<< COMPLETE AQUI >>> */

#include <stdio.h>

int main(){ 
  
  int n1, n2, soma, mult, sub1, sub2, resto1, resto2;
  float div1, div2, somaOpera;
  
  scanf("%d", &n1);
  scanf("%d", &n2);

  if(n1==0 || n2==0){
    return(0);
  }
  
  soma = n1 + n2;
  sub1 = n1 - n2;
  sub2 = n2 - n1;
  mult = n1 * n2;
  div1 = n1/(float)n2;
  div2 = n2/(float)n1;
  resto1 = n1%n2;
  resto2 = n2%n1;
  somaOpera = soma + sub1 + sub2 + mult + div1 + div2 + resto1 + resto2 + (int)div2 + (int)div1;
  
  printf("%d\n", soma);
  printf("%d\n", sub1);
  printf("%d\n", sub2);
  printf("%d\n", mult);
  printf("%.2f\n", div1);
  printf("%.2f\n", div2);
  printf("%d\n", (int)div1);
  printf("%d\n", (int)div2);
  printf("%d\n", resto1);
  printf("%d\n", resto2);
  printf("%.2f\n", somaOpera);
  
  return (0);
  }