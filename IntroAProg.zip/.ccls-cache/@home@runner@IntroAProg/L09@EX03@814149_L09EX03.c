/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 09 - Exercício 03 - Varejo de Tadeu
 *
 *  Instruções
 *  ----------
 *
 *	Este arquivo contém o código que auxiliará no desenvolvimento do
 *	exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */

/// ---- ATENCAO: NAO ALTERAR DAQUI ---->
#include <stdio.h>

#define SemREGULAR	"Nenhum cliente regular.\n"
#define CADASTRO 	"Compra cadastrada!\n"
#define INVALIDA 	"Operacao invalida!\n"

typedef struct compra{
    double valor;
    long cpf;
    int qntProdutos;
} Compra;

typedef struct cliente{
    long cpf;
    int retornos;
} Cliente;

void cadastrarCompra(Compra compras[], Cliente clientes[], double valor, long cpf, int qnt);
void cadastrarCliente(Cliente clientes[], long cpf);
int mediaProdutos(Compra compras[]);
double mediaGasto(Compra compras[]);
double mediaPrecoProduto(Compra compras[]);
void clientesRegulares(Cliente clientes[]);

int main(){
	int op;
	Compra compras[100];
	Cliente clientes[100];
	double valor;
	long int cpf;
	int qnt;

    for (int i = 0; i < 100; i++){
        compras[i].cpf = 0;
        compras[i].valor = 0;
        compras[i].qntProdutos = 0;
        clientes[i].retornos = 0;
        clientes[i].cpf = 0;
    }

	do {
		scanf("%d", &op);
		switch(op){
			case 0:
				return (0);
			case 1:
				scanf("%lf", &valor);
				scanf("%ld", &cpf);
				scanf("%d", &qnt);
				cadastrarCompra(compras, clientes, valor, cpf, qnt);
				cadastrarCliente(clientes, cpf);
				printf("Compra cadastrada!\n");
				break;
			case 2:
				printf("%d\n", mediaProdutos(compras));
				break;
			case 3:
				printf("R$%.2lf.\n",mediaGasto(compras));
				break;
			case 4:
				printf("R$%.2lf.\n",mediaPrecoProduto(compras));
				break;
			case 5:
				clientesRegulares(clientes);
				break;
			default:
				printf("Operacao invalida!\n");
				break;
		}

	} while(op != 0);

	return (0);
} /// <---- ATE AQUI!!! ----


/// ---- APENAS IMPLIMENTE AS FUNCOES DAQUI PRA BAIXO

/* <<< COMPLETE AQUI >>> */

void cadastrarCompra(Compra compras[], Cliente clientes[], double valor, long cpf, int qnt){
  int i;
  for (i = 0; i<100; i++){
    if (compras[i].qntProdutos == 0){
      compras[i].valor = valor;
      compras[i].cpf = cpf;
      compras[i].qntProdutos = qnt;
      break;
    }
  }
}

void cadastrarCliente(Cliente clientes[], long cpf){
  int i, j = 0;
  for (i=0; i<100; i++){
    if (cpf == clientes[i].cpf){
      clientes[i].retornos ++;
      j=1;
      break;
      }
  }
  if (j == 0){
    for (i=0; i<100; i++){
      if (clientes[i].cpf == 0){
        clientes[i].cpf = cpf;
        clientes[i].retornos = 1;
        break;
        }
      }
    }
  
}

int mediaProdutos(Compra compras[]){
  int i=0, n = 0;
  double media = 0;
  for (i=0;i<100;i++){
    if (compras[i].qntProdutos > 0){
      media += compras[i].qntProdutos;
      n += 1;
    }
    else{
      n += 0;
    }
  }
  if (n == 0){
    media = 0;
  }
  else{
  media /= n;
  }
  return media;
  
}

double mediaGasto(Compra compras[]){
  int i=0, n = 0;
  double media = 0;
  for (i=0;i<100;i++){
    media += compras[i].valor;
    if (compras[i].qntProdutos > 0){
      n += 1;
    }
    else{
      n += 0;
    }
  }
  if (n == 0){
    media = 0;
  }
  else{
  media /= n;
  }
  return media;
}

double mediaPrecoProduto(Compra compras[]){
  int i=0, n = 0;
  double media = 0;
  for (i=0;i<100;i++){
    if (compras[i].qntProdutos > 0){
      media += (compras[i].valor);
      n += (double)(compras[i].qntProdutos);
    }
    else{
      n += 0;
    }
  }
  if (n == 0){
    media = 0;
  }
  else{
    media = media/n;
  }
  return media;
}

void clientesRegulares(Cliente clientes[]){
  int i=0, n = 1;
  /*for (i=0;i<100;i++){
      if (clientes[i].cpf != 0)
      printf("%ld - %d\n", clientes[i].cpf, clientes[i].retornos);
      n++;
    }
  */
  //n = 1;
  for (i=0;i<100;i++){
    if (clientes[i].retornos > 2){
      printf("%d - %ld\n", n, clientes[i].cpf);
      n++;
      }
    }
  if (n == 1){  
    printf(SemREGULAR);
      }
}