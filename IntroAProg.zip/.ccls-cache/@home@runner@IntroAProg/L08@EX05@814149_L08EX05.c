#include <stdio.h>

typedef struct circ{
  int x;
  int y;
  float r;
} circ;


int main(){
  int n, i;

  scanf("%d", &n);
  circ c[n];

  for (i = 0; i<n;i++){
    scanf("%d %d %f", &c[i].x, &c[i].y, &c[i].r);
  }

  for (i = 0; i<n;i++){
    printf("%d %d %f\n", c[i].x, c[i].y, c[i].r);
  }
  

  return 0;
}