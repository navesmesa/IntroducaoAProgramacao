#include <stdio.h>

int main(){
  int matriz[3][3], i, j, comando = 1, transposta [3][3], num, diag1, diag2, DetSarre, Cof1, Cof2, Cof3, SomaCof;

 for (i = 0; i<3;i++){
   for (j = 0; j<3;j++){ 
      scanf("%d", &matriz[i][j]);
      }
  }

  while (comando!=0){
    scanf("%d", &comando);
    //Transposta

    if (comando == 2){
        for (i = 0; i<3;i++){
    for (j = 0; j<3;j++){ 
        transposta [i][j] = matriz[j][i];
      }
          }
      for (i = 0; i<3;i++){
        for (j = 0; j<3;j++){ 
        matriz[i][j] = transposta[i][j];
      }
      }
      }

    //Mult

  if (comando == 1){
      scanf("%d", &num);

      for (i = 0; i<3;i++){
        for (j = 0; j<3;j++){ 
        matriz[i][j] *= num;
      }
        }
        
      }
    
    //Sarre

  if (comando == 3){
      diag1 = (matriz[0][0]*matriz[1][1]*matriz[2][2]) + (matriz[0][1]*matriz[1][2]*matriz[2][0]) + (matriz[0][2]*matriz[1][0]*matriz[2][1]);
      diag2 = (matriz[0][2]*matriz[1][1]*matriz[2][0]) + (matriz[0][0]*matriz[1][2]*matriz[2][1]) + (matriz[0][1]*matriz[1][0]*matriz[2][2]);

      DetSarre = diag1 - diag2;

      printf("%d %d\n%d\n", diag1, -diag2, DetSarre);
    }
      
    //Laplace
  if (comando == 4){
    Cof1 = matriz[0][0] * ((matriz[1][1]*matriz[2][2]) - (matriz[1][2] * matriz[2][1]));
    Cof2 = - matriz[1][0] * ((matriz[0][1]*matriz[2][2]) - (matriz[2][1] * matriz[0][2]));
    Cof3 = matriz[2][0] * ((matriz[0][1]*matriz[1][2]) - (matriz[1][1] * matriz[0][2]));
    
  SomaCof = Cof1 + Cof2 + Cof3;

  printf("%d %d %d\n%d\n", Cof1, Cof2, Cof3, SomaCof);
    }
  }
  
  for (i = 0; i<3;i++){
    for (j = 0; j<3;j++){ 
      printf("%d ", matriz[i][j]);
      }
    printf("\n");
  }
  
  return 0;
}