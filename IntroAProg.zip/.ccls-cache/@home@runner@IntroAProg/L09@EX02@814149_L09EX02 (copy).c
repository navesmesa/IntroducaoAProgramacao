/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: IntroduÃ§Ã£o Ã  ProgramaÃ§Ã£o
 *  Prof. Tiago A. Almeida e Jurandy Almeida
 *
 *  Lista 09 - ExercÃ­cio 02 - Buraco da Lacraia Extreme 
 *
 *  InstruÃ§Ãµes
 *  ----------
 *
 *	Este arquivo contÃ©m o cÃ³digo que auxiliarÃ¡ no desenvolvimento do
 *	exercÃ­cio. VocÃª precisarÃ¡ completar as partes requisitadas.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA:
 *  Nome:
 *
 * ================================================================== */

/// ---- ATENCAO: NAO ALTERAR DAQUI ---->
#include <stdio.h>

/* PROTOTIPOS DAS FUNCOES */
void checarCasa();
void moverLeste();
void moverOeste();
void moverNorte();
void moverSul();

int main(){
	char lab[12][12];

	for(int i = 0; i < 11; i++)
		for(int j = 0; j < 11; j++)
			scanf(" %c", &lab[i][j]);

  char op;
  int x, y, posicaoatual[1][1];

	while(1) {
		scanf("%c", &op);
		switch(op) {
		  case 'd': moverLeste(); break;
		  case 'e': moverOeste(); break;
		  case 'f': moverNorte(); break;
		  case 't': moverSul(); break;
		}
		
		checarCasa(x, y);

	}
} /// <---- ATE AQUI!!! ----


/// ---- APENAS IMPLIMENTE AS FUNCOES DAQUI PRA BAIXO

/* <<< COMPLETE AQUI >>> */

void checarCasa(int x, int y, char lab[12][12]){
  if(lab[x][y] == 'B'){
    printf("Morreu!\n");
    return 0;
  }
  else if (lab[x][y] = 'X'){
    lab[x][y] = 'E';
  }
  else if (lab[x][y] = 'F'){
    printf("Acabou!\n");
    return 0;
  }
}
void moverLeste(){
  
}
void moverOeste();
void moverNorte();
void moverSul();