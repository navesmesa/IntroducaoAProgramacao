/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 01 - Exercício 03 - Jeanne Louise Calment
 *
 *  Instruções
 *  ----------
 *
 *	Este arquivo contém o código que auxiliará no desenvolvimento do
 *	exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */

/* <<< COMPLETE AQUI >>> */

/*
Entrada1: Idade
Entrada2: Ano em que se completou a idade
Saída: Ano em que se completará 122 anos

AnoNasc = AnoIdade - Idade
Aniv122 = AnoNasc+122


*/

#include <stdio.h>

int main(){

  int Idade, AnoIdade, AnoNasc, Aniv122;

  scanf("%d", &Idade);
  scanf("%d", &AnoIdade);
  
  AnoNasc = AnoIdade - Idade;
  Aniv122 = AnoNasc + 122;
  
  printf("%d\n", Aniv122);

  return(0);
}
