/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida e Prof. Jurandy Almeida
 *
 *  Lista 03 - Exercício 03 - Tabela Verdade
 *
 *  Instruções
 *  ----------
 *
 *  Este arquivo contém o código que auxiliará no desenvolvimento do
 *  exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *  Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */

#define VERDADEIRO "V\n"
#define FALSO "F\n"
#define INVALIDO "entrada inválida!\n"

/* <<< COMPLETE AQUI >>> */


#include <stdio.h>

int main(){
  char valor1, valor2, operac;

  scanf("%c\n%c\n%c", &valor1, &valor2, &operac);
    
  //printf("%c %c %c", valor1, valor2, operac);

  switch(valor1 | valor2){
    case 'F':
      break;
    case 'V':
      break;
    default:
      printf("entrada inválida!\n");
      return(0);
  }

  switch(operac){
    case 'E':
      break;
    case  'O':
      break;
    case 'I':
      break;
    case 'B':
      break;
    default:
      printf("entrada inválida!\n");
  }
  
  if (operac == 'E'){
    if (valor1 == 'V' && valor2 == 'V'){
      printf("V\n");
    }
    if (valor1 == 'V' && valor2 == 'F'){
      printf("F\n");
    }
    if (valor1 == 'F' && valor2 == 'V'){
      printf("F\n");
    }
    if (valor1 == 'F' && valor2 == 'F'){
      printf("F\n");
    }
  }
  else if (operac == 'O'){
    if (valor1 == 'V' && valor2 == 'V'){
      printf("V\n");
    }
    if (valor1 == 'V' && valor2 == 'F'){
      printf("V\n");
    }
    if (valor1 == 'F' && valor2 == 'V'){
      printf("V\n");
    }
    if (valor1 == 'F' && valor2 == 'F'){
      printf("F\n");
    }
  }
  else if (operac == 'I'){
    if (valor1 == 'V' && valor2 == 'V'){
      printf("V\n");
    }
    if (valor1 == 'V' && valor2 == 'F'){
      printf("F\n");
    }
    if (valor1 == 'F' && valor2 == 'V'){
      printf("V\n");
    }
    if (valor1 == 'F' && valor2 == 'F'){
      printf("V\n");
    }
  }
  else if (operac == 'B'){
    if (valor1 == 'V' && valor2 == 'V'){
      printf("V\n");
    }
    if (valor1 == 'V' && valor2 == 'F'){
      printf("F\n");
    }
    if (valor1 == 'F' && valor2 == 'V'){
      printf("F\n");
    }
    if (valor1 == 'F' && valor2 == 'F'){
      printf("V\n");
    }
  }
  
  return(0);
}