#include <stdio.h>

int main(){
  int i = 0;
  char vetor[100], sc= 0;

  while(sc!=35){
    scanf("%c", &sc);
    vetor[i] = sc;
    i++;
  }

  for(i=0; i<10;i++){
    printf("%d ", vetor[i]);
  }
  
  return 0;
}