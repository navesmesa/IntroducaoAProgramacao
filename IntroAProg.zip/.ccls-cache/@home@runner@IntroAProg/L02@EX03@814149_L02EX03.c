#include <stdio.h>

int main(){
  
  int trabalhadores, dias, horas, minutos;
  double precohora, total = 0, totalhoras = 0, extras;
  scanf("Trabalhadores:%d/Dias:%d/Hora:%d/Minutos:%d/PrecoHora:%lf/Extras:%lf", &trabalhadores, &dias, &horas, &minutos, &precohora, &extras);

  totalhoras = horas + (double)minutos/60 + dias*9;
  total = (totalhoras * precohora) * trabalhadores;
  total += extras;

  printf("%.2f\n", total);
  
}