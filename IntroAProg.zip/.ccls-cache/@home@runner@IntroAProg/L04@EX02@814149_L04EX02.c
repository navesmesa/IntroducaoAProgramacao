/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 04 - Exercício 02 - John, o pipoqueiro
 *
 *  Instruções
 *  ----------
 *
 *	Este arquivo contém o código que auxiliará no desenvolvimento do
 *	exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */


/* <<< COMPLETE AQUI >>> */

#include <stdio.h>

int main(){ 
  char comando;
  int v;
  float a=2.5, c, caixa=5000, estoque = 3;
  while (0==0){
    scanf("%c", &comando);
    switch(comando){
      case '\n':
        break;
      case 'S': 
        printf("RS:%.2f\n", caixa);
        return(0);
      case 'V':
        scanf("%d", &v);
        if ((estoque - v * 0.1)<0){
          printf("Insumo insuficiente!\n");
          printf("RS:%.2f\n", caixa);
          break;
        }
        else{
          estoque-=v*0.1;
          caixa += v * a;
          printf("RS:%.2f\n", caixa);
          break;
          }
      case 'C': 
        scanf("%f", &c);
        if ((caixa - c * 0.01)<0){
          printf("Saldo insuficiente!\n");
          printf("RS:%.2f\n", caixa);
          break;
        }
        else{
        estoque += (c/1000);
        caixa -= (c * 0.01);
        printf("RS:%.2f\n", caixa);
        break;
          }
      case 'A':
        scanf("%f", &a);
        printf("RS:%.2f\n", caixa);
        break; 
      default:
        printf("Opcao Invalida!\n");
      }
    }
 return(0); 
}