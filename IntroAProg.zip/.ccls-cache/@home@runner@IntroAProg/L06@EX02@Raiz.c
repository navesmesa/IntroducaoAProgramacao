#include <stdio.h>

int main(){
  int n, numero;
  scanf("%d", &numero);
  float recorre = numero;
  
   
  for (n = 0; n < 10; ++n)
    recorre = recorre/2 + numero/(2*recorre);

  printf("%f", recorre);
  
  return 0;
}

/*

#include <stdio.h>

int main(){
  int n, i;

  scanf("%d", &n);

  float valores[n], media, fatorsoma[n], somaft;

  for (i=0; i<n;i++){
    scanf("%f", &valores[i]);
    media += valores[i];
  }
  
  media/=n;

  printf("%f\n", media);

  for (i = 0; i<n; i++){
    fatorsoma[i] = (valores[i] - media) * (valores[i] - media);
    somaft += fatorsoma[i];
  }

  float calcularaiz = somaft;
  
  for (i = 0; i < 10; i++)
    calcularaiz = calcularaiz/2 + somaft/(2*calcularaiz);

  printf("%f\n", somaft);
  //printf("%f\n", calcularaiz);
  
  return 0;
}


*/