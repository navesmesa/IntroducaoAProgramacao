#include <stdio.h>

int main(){
  int n, i, exc, pos, valor, tamanho = 0;
  char comando;
  scanf("%d", &n);

  //printf("%d\n", n);
  
  int vetor[n];

  for (i=0;i<n;i++){
    vetor[i] = 999;
  }
  /*for (i=0;i<n;i++){
    printf("%d\n",vetor[i]);
  }
  */
while(1){
  scanf("%c", &comando);
  
  if (comando == 65){
    exc = 0;
    for(i=0;i<=n;){
      if(i == n){
        printf("Exception!\n");
        exc = 1;
        break;
      }
      if (vetor[i] == 999){
        scanf("%d", &vetor[i]);
        break;
      }
      else{
        i++;
      }
    }
    if (exc == 0){
    printf("[");
    for(i=0;i<n;i++){
      if(vetor[i]!=999){
        printf("'%d'", vetor[i]);
      }
      if (vetor[i+1]!=999 && vetor[i+1]!=0 && i+1!=n){
        printf(" ");
      }
    }
    printf("]\n");
    tamanho+=1;
    printf("tamanho %d\n", tamanho);
  }
    }
  else if (comando == 80){
    scanf("%d", &pos);
    exc = 0;
    if (pos<n){
      for(i = pos;i<n;i++){
        vetor[i] = vetor[i+1];
      }
      vetor[n-1] = 999;
    }
    else{
      printf("Exception!\n");
      exc = 1;
    }
    if (exc == 0){
    printf("[");
    for(i=0;i<n;i++){
      if(vetor[i]!=999){
        printf("'%d'", vetor[i]);
      }
      if (vetor[i+1]!=999 && vetor[i+1]!=0 && i+1!=n){
        printf(" ");
      }
    }
    printf("]\n");
    tamanho-=1;
    printf("tamanho %d\n", tamanho);
  }
  }
  else if (comando == 73){
    scanf("%d %d", &pos, &valor);
    exc = 0;
    if (pos<tamanho){
      for(i = tamanho;i>pos;i--){
        vetor[i] = vetor[i-1];
      }
      vetor[pos] = valor;
    }
    else{
      printf("Exception!\n");
      exc++;
    }
    if (exc == 0){
    printf("[");
    for(i=0;i<n;i++){
      if(vetor[i]!=999){
        printf("'%d'", vetor[i]);
      }
      if (vetor[i+1]!=999 && vetor[i+1]!=0 && i+1!=n){
        printf(" ");
      }
    }
    printf("]\n");
    tamanho+=1;
    printf("tamanho %d\n", tamanho);
  }
  }
  }
  
  return 0;
}