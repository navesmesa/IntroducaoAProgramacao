/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 10 - Exercício 01 - Contador de Palavras
 *
 *  Instruções
 *  ----------
 *
 *	Este arquivo contém o código que auxiliará no desenvolvimento do
 *	exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */

#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define MAX         5000
#define VOGAIS      "Vogais = %d\n"
#define CONSOANTES  "Consoantes = %d\n"
#define ESPECIAIS   "Especiais = %d\n"
#define PALAVRAS    "Palavras = %d\n"

int contavogal(char texto[]);
int contaconso(char texto[]);
int contaespeciais(char texto[]);
int contapalavras(char texto[]);

int main(){

    /* <<< COMPLETE AQUI >>> */

  char texto[MAX];
  int vogais = 0, palavras = 0, especiais = 0, consoantes = 0;

  while (scanf("%5000s", texto) != EOF){
    //printf("%s\n", texto);
    vogais += contavogal(texto);
    //printf("%d\n", vogais);
    consoantes += contaconso(texto);
    especiais += contaespeciais(texto);
    palavras += contapalavras(texto);
    }

  
  printf(VOGAIS, vogais);
  printf(CONSOANTES, consoantes);
  printf(ESPECIAIS, especiais);
  printf(PALAVRAS, palavras);

    return (0);
}

int contavogal(char texto[]){
  int i, contador = 0;

  for(i = 0; texto[i] != '\0'; i++){
    if (texto[i] == '\0'){
      return contador;
      break;
    }
    else if (texto[i] == 'a' || texto[i] == 'e' || texto[i] == 'o' || texto[i] == 'i'|| texto[i] == 'u' || texto[i] == 'A' || texto[i] == 'E' || texto[i] == 'O' || texto[i] == 'I'|| texto[i] == 'U'){
      contador++;
      //printf("%c\n", texto[i]);
    }
  }
  return contador;
}
int contaconso(char texto[]){
  int i = 0, vogais, contador = 0;
  vogais = contavogal(texto);
  for (i = 0; texto[i] != '\0'; i++){
    if (isalpha(texto[i]))
    contador++;
  }
  contador -= vogais;
  return contador;
}
int contapalavras(char texto[]){
  int i, contador = 0;

  for(i = 0; texto[i]!= '\0'; i++){
    if (texto[i] == '\0'){
      return contador + 1;
      break;
    }
    else if (texto[i] == ' '){
      contador++;
      //printf("%c\n", texto[i]);
    }
  }

  return contador + 1;
}
int contaespeciais(char texto[]){
  int i = 0, contador = 0;
  char c;
  
  while (texto[i] != '\0'){
    c = texto[i];
    if (!isalpha(texto[i]) && texto[i] != ' '){
      contador++;
      //printf("%c\n", texto[i]);
    }
    i++;
  }

  return contador;
}