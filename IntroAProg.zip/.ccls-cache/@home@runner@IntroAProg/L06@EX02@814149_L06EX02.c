/* ================================================================== *
 *  Universidade Federal de São Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 06 - Exercício 02 - Desvio Padrão
 *
 *  Instruções
 *  ----------
 *
 *  Este arquivo contém o código que auxiliará no desenvolvimento do
 *  exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *  Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */
 
#include <stdio.h>

/* <<< COMPLETE AQUI >>>*/

int main(){
  int n, i;

  scanf("%d", &n);

  float valores[n], media, fatorsoma[n], somaft, raiz = 0;

  for (i=0; i<n;i++){
    scanf("%f", &valores[i]);
    media += valores[i];
  }
  
  media/=n;

  //printf("%f\n", media);

  for (i = 0; i<n; i++){
    fatorsoma[i] = (valores[i] - media) * (valores[i] - media);
    somaft += fatorsoma[i];
  }

  //printf("%f\n", somaft);

  somaft = somaft/(n-1);
  raiz = somaft;
   
  for (i = 0; i < 10; i++){
    raiz = raiz/2 + somaft/(2*raiz);
    }
    
  printf("Dp=%.2f\n", raiz);
  
  return 0;
}