/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 02 - Exercício 02 - Gasto de energia
 *
 *  Instruções
 *  ----------
 *
 *	Este arquivo contém o código que auxiliará no desenvolvimento do
 *	exercício. Você precisará completar as partes requisitadas.
 *
 *  OBS: Não utilize conceitos ainda não aprendidos em aula, todos os
 *  exercícios podem ser resolvidos apenas com o conteúdo já passado.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */

/* <<< COMPLETE AQUI >>> */

#include <stdio.h>
#define GELADEIRA 0.130
#define MICROONDAS 2
#define CHUVEIRO 3.5
#define ASPIRADOR 0.1
#define COMPUTADOR 0.18

int main(){
  int gelhr, gelmin, microhr, micromin, chuhr, chumin, asphr, aspmin, comphr, compmin;
  float usogel, usomicro, usochu, usoasp, usocomp, custo = 0;

  scanf("%d %d", &gelhr, &gelmin);
  scanf("%d %d", &microhr, &micromin);
  scanf("%d %d", &chuhr, &chumin);
  scanf("%d %d", &asphr, &aspmin);
  scanf("%d %d", &comphr, &compmin);

  usogel = (gelhr + ((float)gelmin/60)) * 0.525;
  usomicro = (microhr + ((float)micromin/60))  * 0.525;
  usochu = (chuhr + ((float)chumin/60))  * 0.525;
  usoasp = (asphr + ((float)aspmin/60))  * 0.525;
  usocomp = (comphr + ((float)compmin/60))  * 0.525;

  custo = (usogel * GELADEIRA) + (usomicro * MICROONDAS) + (usochu * CHUVEIRO) + (usoasp * ASPIRADOR) + (usocomp * COMPUTADOR);

  printf("R$%.2f", custo);
  return(0);
}