/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 08 - Exercício 02 - Dia da semana
 *
 *  Instruções
 *  ----------
 *
 *	Este arquivo contém o código que auxiliará no desenvolvimento do
 *	exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */


#include <stdio.h>

typedef struct data{
  int dia;
  int mes;
  int ano;
} Data;


int main(){
  Data data;
  int A, B, C, D, valor;

  scanf("%d/%d/%d", &data.dia, &data.mes, &data.ano);
  
  if (data.ano > 2399 || data.ano < 1900 || data.dia > 31 || data.dia<1 || data.mes<1 || data.mes > 12){
    printf("data inválida!\n");
    return 0;
  }
  
 // printf("%d/%d/%d\n", data.dia, data.mes, data.ano);

  /// A
  
  A = data.ano - 1900;

 // printf("%d\n", A);


  // B
  
  
  B = A/4;

  if ((data.ano%4 == 0) && data.mes<=2){
    B-=1;
  }

  //printf("%d\n", B);

  ///C
  
  switch (data.mes){
    case 1:
      C = 0;
      break;
    case 2:
      C = 3;
      break;
    case 3:
      C = 3;
      break;
    case 4:
      C = 6;
      break;
    case 5:
      C = 1;
      break;
    case 6:
      C = 4;
      break;
    case 7:
      C = 6;
      break;
    case 8:
      C = 2;
      break;
    case 9:
      C = 5;
      break;
    case 10:
      C = 0;
      break;
    case 11:
      C = 3;
      break;
    case 12:
      C = 5;
      break;
  }

  //printf("%d\n", C);

  /// D

  D = data.dia - 1;

  /// valor

  valor = (A + B + C + D) % 7;

  switch (valor){
    case 0:
      printf("segunda-feira\n");
      break;
    case 1:
      printf("terça-feira\n");
      break;
    case 2:
      printf("quarta-feira\n");
      break;
    case 3:
      printf("quinta-feira\n");  
      break;
    case 4:
      printf("sexta-feira\n");
      break;
    case 5:
      printf("sábado\n");
      break;
    case 6:
      printf("domingo\n");
      break;
    default:
      printf("data inválida!\n");
      break;
  }

  return 0;
}