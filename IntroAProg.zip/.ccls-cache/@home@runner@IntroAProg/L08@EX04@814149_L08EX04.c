/* ================================================================== *
 *  Universidade Federal de São Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 08 - Exercício 04 - K-Alunos
 *
 *  Instruções
 *  ----------
 *
 *  Este arquivo contém o código que auxiliará no desenvolvimento do
 *  exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *  Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */

#include <stdio.h>
#include <math.h>

typedef struct Aluno{
  double P1;
  double P2;
  double L;

} ALUNO;



int main(){
  int n, k, i, j, menor = 0;
  ALUNO Ronildo;
  
  scanf("%lf %lf", &Ronildo.P1, &Ronildo.L);
  scanf("%d", &n);
  scanf("%d", &k);

  ALUNO Outros[n];
  double distancias[n], media;

  for(i=0;i<n;i++){
    scanf("%lf %lf %lf", &Outros[i].P1, &Outros[i].P2, &Outros[i].L);
  }
  for(i=0;i<n;i++){
    distancias[i] = sqrt(((Outros[i].P1 - Ronildo.P1)*(Outros[i].P1 - Ronildo.P1))  + ((Outros[i].L - Ronildo.L)*(Outros[i].L - Ronildo.L)));
  }

for (i=0;i<k;i++){
  for (j=0;j<n;j++){
    if (distancias[j] < distancias[menor]){
      menor = j;
      }
    }
    //printf("%d\n", menor);
    media += Outros[menor].P2;
    distancias[menor] = 100;
    menor = 0;
  }
  media/=k;
  printf("%.1lf\n", media);
  
  return 0;
}