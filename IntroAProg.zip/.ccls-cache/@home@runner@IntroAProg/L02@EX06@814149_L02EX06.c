/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 02 - Exercício 06 - Calculadora de senhas
 *
 *  Instruções
 *  ----------
 *
 *	Este arquivo contém o código que auxiliará no desenvolvimento do
 *	exercício. Você precisará completar as partes requisitadas.
 *
 *  OBS: Não utilize conceitos ainda não aprendidos em aula, todos os
 *  exercícios podem ser resolvidos apenas com o conteúdo já passado.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */

/* <<< COMPLETE AQUI >>> */


#include <stdio.h>

int main(){
  
  char senha1, senha2, senha3, atual1, atual2, atual3;
  int somaatual, somasenha, dif;
  scanf("%c%c%c ", &senha1, &senha2, &senha3);
  scanf("%c%c%c", &atual1, &atual2, &atual3);

  senha1-=65;
  senha2-=65;
  senha3-=65;
  atual1-=65;
  atual2-=65;
  atual3-=65;
  somasenha = (senha1 * 676) + (senha2*26) + senha3;
  somaatual = (atual1 * 676) + (atual2*26) + atual3;

  dif = somasenha-somaatual;

  if(dif<0){
    dif*=-1;
  }
  printf("%d\n", dif);

  return(0);
}