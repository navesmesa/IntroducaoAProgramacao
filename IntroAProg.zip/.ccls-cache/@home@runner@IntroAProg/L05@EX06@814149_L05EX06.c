#include <stdio.h>

int main(){
  unsigned long long int B = 0, P = 1, N, Beprimo = 1, contadorB, C, K, Q, contadorP, Peprimo = 1;

  scanf("%Lu %Lu", &C, &N);
  
  while (Beprimo != 0){
    printf("P %Lu\n", P);
    Beprimo = 0;
    P+=2;
    B = N/P;
    for (contadorB = 2; contadorB <= B/ 2; contadorB++) {
      if (B % contadorB == 0) {
       Beprimo++;
       break;
    }
 }
}

  Q = B + P;
  K = C / Q;
  printf("%Lu\n", K);
  return 0;
}