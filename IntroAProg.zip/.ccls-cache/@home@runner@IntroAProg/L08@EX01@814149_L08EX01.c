/* ================================================================== *
 *  Universidade Federal de São Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 08 - Exercício 01 - Calculadora de números complexos
 *
 *  Instruções
 *  ----------
 *
 *  Este arquivo contém o código que auxiliará no desenvolvimento do
 *  exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *  Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */
#include <math.h>
#include <stdio.h>



typedef struct complexo {
	float real;
	float imaginario;
} Complexo;


int main(){

  /* <<< COMPLETE AQUI >>>*/

  int i, opcoes;
  float somar, somaim, subr, subim, multr, multim, divr, divim, a, b, c, d, mod;
  
  Complexo num[2];
  
  for (i=0;i<2;i++){
    scanf("%f %f", &num[i].real, &num[i].imaginario);
  }

  somar = num[0].real + num[1].real;
  somaim = num[0].imaginario + num[1].imaginario;
  multr = (num[0].real * num[1].real) - (num[0].imaginario * num[1].imaginario);
  multim = (num[0].real * num[1].imaginario)+(num[1].real * num[0].imaginario);

  a = num[0].real;
  b = num[0].imaginario;
  c = num[1].real;
  d = num[1].imaginario;
  scanf("%d", &opcoes);
  while(1){
    if (opcoes == 0){
      break;
    }
    else if (opcoes == 1){
      if(somaim == 0){
        printf("%.2f\n", somar);
      }
      else if(somar == 0){
        printf("%.2f\n", somaim);
      }
      if (somaim>0){
       printf("%.2f +%.2fi\n", somar, somaim); 
      }
      else{
        printf("%.2f %.2fi\n", somar, somaim); 
      }
    }
    else if (opcoes == 2){
      subr = num[0].real - num[1].real;
      subim = num[0].imaginario - num[1].imaginario;

      if (subim>0){
        printf("%.2f +%.2fi\n", subr, subim);
      }
      else if(subim == 0){
        printf("%.2f\n", subr);
      }
      else if(subr == 0){
        printf("%.2f\n", subim);
      }
      else{
         printf("%.2f %.2fi\n", subr, subim);
      }
     
    }
    else if (opcoes == 3){
      subr = num[1].real - num[0].real;
      subim = num[1].imaginario - num[0].imaginario;

      
      if(subim == 0){
        printf("%.2f\n", subr);
      }
      else if(subr == 0){
        printf("%.2fi\n", subim);
        }
      else if (subim>0){
        printf("%.2f +%.2fi\n", subr, subim);
      }
      else{
         printf("%.2f %.2fi\n", subr, subim);
      }
    }
    else if (opcoes == 4){
      if(multim == 0){
        printf("%.2f\n", multr);
      }
      else if(multr == 0){
        printf("%.2fi\n", multim);
        }
      else if(multim>0){
        printf("%.2f +%.2fi\n", multr, multim);
      }
      else{
        printf("%.2f %.2fi\n", multr, multim);
      }
    }
    else if (opcoes == 5){
      if (num[1].real == 0 || num[1].imaginario == 0){
        printf("Divisao por zero\n");
        }
      else{
        divr = ((a*c) + (b * d)) / ((c*c) + (d*d));
        divim = ((b*c) - (a*d)) / ((c*c) + (d*d));

      if (divim>0){
        printf("%.2f +%.2fi\n", divr, divim);
      }
      else if(divim == 0){
        printf("%.2f\n", divr);
      }
      else if(divr == 0){
        printf("%.2f\n", divim);
      }
      else{
         printf("%.2f %.2fi\n", divr, divim);
      }
        
      }      
    }
    else if (opcoes == 6){
      if (num[1].real == 0 || num[1].imaginario == 0){
        printf("Divisao por zero\n");
        }
      else{
        divr = ((a*c) + (b * d)) / ((a*a) + (b*b));
        divim = ((d*a) - (c*b)) / ((a*a) + (b*b));

      if (divim>0){
        printf("%.2f +%.2fi\n", divr, divim);
      }
      else if(divim == 0){
        printf("%.2f\n", divr);
      }
      else if(divr == 0){
        printf("%.2f\n", divim);
      }
      else{
         printf("%.2f %.2fi\n", divr, divim);
      }
        
      }      
    }
    else if (opcoes == 7){
      
      mod = ((a * a) + (b * b));
      mod = sqrt(mod);
      printf("%.2f\n", mod);
    }
    else if (opcoes == 8){
      
      mod = ((c * c) + (d * d));
      mod = sqrt(mod);
      printf("%.2f\n", mod);
    }
    else{
      printf("Operacao invalida!\n");
    }
    scanf("%d", &opcoes);
  }
  
	return (0);
}