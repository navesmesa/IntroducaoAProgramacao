/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida e Jurandy Almeida
 *
 *  Lista 03 - Exercício 01 - Pedra, Papel e Tesoura
 *
 *  Instruções
 *  ----------
 *
 *	Este arquivo contém o código que auxiliará no desenvolvimento do
 *	exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */


#include <stdio.h>

int main(){
  char cheetara, panthro;
  int caso;
  // PS RS SP
  
  scanf("%c\n%c", &panthro, &cheetara);  

  switch (cheetara | panthro){
    case 'P':
      break;
    case 'R':
      break;
    case 'S':
      break;
    default:
      printf("INVALIDA");
      return(0);
  }
  
  if (cheetara == panthro){
    printf("EMPATE\n");
  }
  if (cheetara == 'R' && panthro == 'S'){
    printf("CHEETARA\n");
  }
  if (cheetara=='R' && panthro == 'P'){
    printf("PANTHRO\n");
  }
  if (cheetara=='P'&& panthro == 'R'){
    printf("CHEETARA\n");
  }
  if (cheetara=='P' && panthro == 'S'){
    printf("PANTHRO\n");
  }
  if (cheetara=='S'&& panthro == 'P'){
    printf("CHEETARA\n");
  }
  if (cheetara=='S' && panthro == 'R'){
    printf("PANTHRO\n");
  }

  return(0);
}