#include <stdio.h>

int main(){
  int movimento1, movimento2, movimento3, movimento4;

  scanf("%d", &movimento1);

  switch(movimento1){
    case 1:
      printf("Caiu no Buraco!\n");
      return(0);
    case 2:
      scanf("%d", &movimento2);
      break;
    case 3:
      scanf("%d", &movimento2);
      break;
    default:
      printf("Caminho Invalido!\n");
      return(0);
  }
    switch(movimento2){
    case 11:
      printf("Caiu no Buraco!\n");
      return(0);
    case 5:
      scanf("%d", &movimento3);
      break;
    case 6:
      scanf("%d", &movimento3);
      break;
    default:
      printf("Caminho Invalido!\n");
      return(0);
  }
    switch(movimento3){
    case 4:
      printf("Caiu no Buraco!\n");
      return(0);
    case 7:
      printf("Caiu no Buraco!\n");
      return(0);
    case 9:
      scanf("%d", &movimento4);
      break;
    case 8:
      scanf("%d", &movimento4);
      break;
    default:
      printf("Caminho Invalido!\n");
      return(0);
  }
  switch(movimento4){
    case 17:
      printf("Caiu no Buraco!\n");
      return(0);
    case 12:
      printf("Caiu no Buraco!\n");
      return(0);
    case 0:
      printf("Parabens!\n");
      return(0);
    default:
      printf("Caminho Invalido!\n");
      return(0);
  }

  return(0);
  }
