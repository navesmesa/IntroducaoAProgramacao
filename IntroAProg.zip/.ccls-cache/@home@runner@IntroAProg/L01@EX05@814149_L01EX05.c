/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 01 - Exercício 05 - Dona Gertrudes
 *
 *  Instruções
 *  ----------
 *
 *	Este arquivo contém o código que auxiliará no desenvolvimento do
 *	exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */

/* <<< COMPLETE AQUI >>> */


#include <stdio.h>

int main(){

  int valor, moeda1, moeda5, moeda10, moeda25, moeda50, moeda100, qntd;

  scanf("%d", &valor);
  moeda1 = 1;
  moeda5 = 5;
  moeda10 = 10;
  moeda25 = 25;
  moeda50 = 50;
  moeda100 = 100;

  while(valor >= moeda100){
    valor-=moeda100;
    qntd+=1;
    if (valor == 0){
      printf("%d\n", qntd);
    }
    }
  while(valor >= moeda50){
      valor-=moeda50;
      qntd+=1;
    if (valor == 0){
      printf("%d\n", qntd);
    }
    }
  while(valor >= moeda25){
      valor-=moeda25;
      qntd+=1;
    if (valor == 0){
      printf("%d\n", qntd);
    }
    }
  while(valor >= moeda10){
      valor-=moeda10;
      qntd+=1;
    if (valor == 0){
      printf("%d\n", qntd);
    }
    }
  while(valor >= moeda5){
      valor-=moeda5;
      qntd+=1;
    if (valor == 0){
      printf("%d\n", qntd);
    }
    }
  while(valor >= moeda1){
      valor-=moeda1;
      qntd+=1;
    if (valor == 0){
      printf("%d\n", qntd);
    }
    }
  return(0);
}