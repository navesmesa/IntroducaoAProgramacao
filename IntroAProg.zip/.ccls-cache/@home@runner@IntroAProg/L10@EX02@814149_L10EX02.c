/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 10 - Exercício 02 - NotePad
 *
 *  Instruções
 *  ----------
 *
 *	Este arquivo contém o código que auxiliará no desenvolvimento do
 *	exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */

#include <stdio.h>
#include <string.h>
#include <ctype.h>

int encontrar(char frase[], char palavra[]);
void reescrever(char frase[], char p1[], char p2[]);

int main(){

    /* <<< COMPLETE AQUI >>> */
    char frase[10000], palavra[10000], p1[10000], p2[10000];
    int qtd = 0;
  
    scanf("%[^.]", frase); 
    
    printf("%s\n", frase);

    char opcao;

    while(opcao != 'F'){
      printf("b\n");
      scanf("%c", &opcao);
      if (opcao == 'F'){
        printf("%s\n", frase);
        return 0;
      }
      else if (opcao == 'E'){
        printf("A\n");
        scanf("%s", frase); 
        qtd = encontrar(frase, palavra);
        printf("%d\n", qtd);
      }
      else if (opcao == 'R'){
        return 0;
      }
    }

    return (0);
}

// Implemente as funcoes encontrar() e reescrever()

int encontrar(char frase[], char palavra[]){
  int contador, i, tamanho, qtd;
  
  tamanho = strlen(palavra);

  for(i = 0; frase[i] != '\0'; i ++){
    if (palavra[i] == frase[i]){
      contador++;
      if (contador == tamanho){
        qtd++;
      }
    }
    else if (palavra[i] != frase[i]){
      contador = 0;
    }
  }
  
  return qtd;
}