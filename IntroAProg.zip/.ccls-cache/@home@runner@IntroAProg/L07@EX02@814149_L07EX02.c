#include <stdio.h>

int main(){
  int tabuleiro[10][10], i, j, total[10],contador[10], n, jogadas, jogadax, jogaday;
  float dano[10];

  for (i=0;i<10;i++){
    for (j=0;j<10;j++){
      scanf("%d", &tabuleiro[i][j]);
    }
  }

  for (i=0;i<10;i++){
      total[i] = 0;
      contador[i] = 0;
  }

  for (i=0;i<10;i++){
    for (j=0;j<10;j++){
      n = tabuleiro[i][j];
      total[n]+=1;
    }
  }
  scanf("%d", &jogadas);

  for(i=0;i<jogadas;i++){
    scanf("%d %d", &jogadax, &jogaday);
    if (tabuleiro[jogaday][jogadax]!=0){
      printf("Embarcacao atingida!\n");
      tabuleiro[jogaday][jogadax] = 0;
    }
    else{
      printf("Agua!\n");
    }
  }

  
  
  for (i=0;i<10;i++){
    for (j=0;j<10;j++){
      n = tabuleiro[i][j];
      contador[n]+=1;
    }
  }
  for (i=0;i<10;i++){
      dano[i] = 100 - ((float)contador[i]*100/total[i]);
    }

  for (i = 1; i<10;i++){
    if(total[i]!=0){
    printf("Dano [%d]: %.2f%%\n", i, dano[i]);
      }
  }
  
  
  
  return 0;
}