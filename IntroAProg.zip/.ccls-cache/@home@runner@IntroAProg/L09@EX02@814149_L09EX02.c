/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida e Jurandy Almeida
 *
 *  Lista 09 - Exercício 02 - Buraco da Lacraia Extreme 
 *
 *  Instruções
 *  ----------
 *
 *	Este arquivo contém o código que auxiliará no desenvolvimento do
 *	exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */

/// ---- ATENCAO: NAO ALTERAR DAQUI ---->
#include <stdio.h>

/* PROTOTIPOS DAS FUNCOES */
int checarCasa(int posicao[], char lab[11][11]);
int moverLeste(int posicao[]);
int moverOeste(int posicao[]);
int moverNorte(int posicao[]);
int moverSul(int posicao[]);

int main(){
    char lab[11][11];
    char op;
    int posicao[2];
    int aux = 0;

  for(int i = 0; i < 11; i++){
    for(int j = 0; j < 11; j++){
      scanf(" %c", &lab[i][j]);
      if(lab[i][j] == 'e'){
        posicao[0] = i;
        posicao[1] = j;
      }
    }
  }
    
  while(1){
	scanf("%c ", &op);
  //printf("op %c\n", op);
  //printf("%d %d\n", posicao[0], posicao[1]);
	switch(op){
            case 'L':
                if(moverLeste(posicao) == -1){
                    printf("Saiu do tabuleiro!\n");
                    return 0;
                }
                break;

            case 'O': 
                if(moverOeste(posicao) == -1){
                    printf("Saiu do tabuleiro!\n");
                    return 0;
                }
                break;

            case 'N':
                if(moverNorte(posicao) == -1){
                    printf("Saiu do tabuleiro!\n");
                    return 0;
                }
                break;

            case 'S':
                if(moverSul(posicao) == -1){
                    printf("Saiu do tabuleiro!\n");
                    return 0;
                }
                break;
	}

        if(checarCasa(posicao, lab) == -1){
            printf("Morreu!\n");
            return 0;
        }

        if(checarCasa(posicao, lab) == 1){
            printf("Encontrou a saida!\n");
            return 0;
        }
    }
} 

/// <---- ATE AQUI!!! ----


/// ---- APENAS IMPLEMENTE AS FUNCOES DAQUI PRA BAIXO

/* <<< COMPLETE AQUI >>> */


int checarCasa(int posicao[], char lab[11][11]){
      if (lab[posicao[0]][posicao[1]] == 'F')
        return 1;
      else if(lab[posicao[0]][posicao[1]] == 'B')
        return -1;
      else
        return 0;
        
}
int moverLeste(int posicao[]){
  if (posicao[1] + 1 > 10){
    return -1;
  }
  else{
    posicao[1] += 1;
    return 0;
  }
}

int moverOeste(int posicao[]){
  if (posicao[1] - 1 < 0){
    return -1;
  }
  else{
    posicao[1] -= 1;
    return 0;
  }
}

int moverNorte(int posicao[]){
  if (posicao[0] - 1 < 0){
    return -1;
  }
  else{
    posicao[0] -= 1;
    return 0;
  }
}
int moverSul(int posicao[]){
  if (posicao[0] + 1 > 10){
    return -1;
  }
  else{
    posicao[0] += 1;
    return 0;
  }
}