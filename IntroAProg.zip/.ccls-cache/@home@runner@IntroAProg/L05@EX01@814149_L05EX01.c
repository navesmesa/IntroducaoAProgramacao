/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 05 - Exercício 01 - Números Perfeitos e Triangulares
 *
 *  Instruções
 *  ----------
 *
 *	Este arquivo contém o código que auxiliará no desenvolvimento do
 *	exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */


/* <<< COMPLETE AQUI >>> */

#include <stdio.h>

int main(){
	int n1original, n1, n2, contadorperfeito = 0, a, b, p=1, tr2, tr1, contadortriangular = 0, qtdperf = 0, qtdtri = 0;
	scanf("%d %d", &n1original, &n2);
  n1 = n1original;
  printf("Perfeitos:");

  for(;n1<=n2;n1++){
    for (a=1;a<=n1/2;a++){
	    if ((n1%a) == 0){
		    contadorperfeito += a;
	    }
      else{
        contadorperfeito = contadorperfeito;
      }  
      //printf("\n %d %d %d\n", a, contadorperfeito, n1);
  }
    if (contadorperfeito == n1  && contadorperfeito!=0){
	      printf(" %d", contadorperfeito);
        qtdperf +=1;
      }
    contadorperfeito=0;
  }

  if (qtdperf==0){
    printf(" vazio\n");
    }
  else{
    printf("\n");
  }
  //printf("\ncontador perfeito: %d\n", contadorperfeito);
  //printf("\nqtde perf: %d\n", qtdperf);

  // Parte triangular

  printf("Triangulares:");

  n1 = n1original;
  
	for (; n1 <= n2; n1++){
		for (contadortriangular = 3;contadortriangular<=n2;contadortriangular++){
			tr1=contadortriangular-1;
			tr2=contadortriangular-2;
				if((contadortriangular*tr2*tr1)==n1){
					printf(" %d", n1);
          qtdtri+=1;
}	

}
}
if(qtdtri==0){
  printf(" vazio\n");
}
else{
  printf("\n");
}
	return 0;
}