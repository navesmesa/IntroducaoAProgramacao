/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 01 - Exercício 01 - Nota m2 para obter média M
 *
 *  Instruções
 *  ----------
 *
 *	Este arquivo contém o código que auxiliará no desenvolvimento do
 *	exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */

/* <<< COMPLETE AQUI >>> */

#include <stdio.h>

int main(){

  float M, M1, M2, P1, P2;

  scanf("%f", &M);
  scanf("%f", &M1);
  scanf("%f", &P1);
  scanf("%f", &P2);

  M2 = ((M*P1)+(M*P2) - (P1*M1))/P2;
  printf("%.2f\n", M2);
  
  return(0);
}