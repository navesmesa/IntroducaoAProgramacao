/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida e Jurandy Almeida
 *
 *  Lista 03 - Exercício 05 - Tipos de Triângulos
 *
 *  Instruções
 *  ----------
 *
 *  Este arquivo contém o código que auxiliará no desenvolvimento do
 *  exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *  Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */

/* <<< COMPLETE AQUI >>> */

#include <stdio.h>

int main(){
  int lado1, lado2, lado3;

  scanf("%d\n%d\n%d", &lado1, &lado2, &lado3);

  if (lado1 + lado2 < lado3 || lado3 + lado2 < lado1 || lado1 + lado3 < lado2){
    printf("Nao forma triangulo\n");
    return(0);
  }
    
  else if (lado1 == lado2 && lado2 == lado3){
    printf("Triangulo equilatero\n");
  }
  else if (lado1 == lado2 && lado2!= lado3 || lado2==lado3 && lado3!=lado1 || lado3==lado1 && lado1!=lado2){
    printf("Triangulo isosceles\n");
  }
  else if(lado1!=lado2 && lado2!=lado3){
    printf("Triangulo escaleno\n");
  }
  
  return(0);
}