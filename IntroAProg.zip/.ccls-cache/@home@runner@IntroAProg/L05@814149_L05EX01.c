/* Passos:

	Número perfeito: igual a soma dos seus divisores inteiros, ex: 6 e 28
	Número triangular: resultado da multiplicação de números consecutivos, ex: 6, 24, 120

19/7 23hrs: Identifica se o número é ou não perfeito
            Identifica a lista de números triangulares (Correto)

*/

#include <stdio.h>

int main(){
	int n1, n2, contadorperfeito = 0, a, b, tr2, tr1, contadortriangular;
	scanf("%d", &n1);

	for (a=1;a<n1;a++){
	if ((n1%a) == 0){
		contadorperfeito += a;
	}
    else{
      contadorperfeito = contadorperfeito;
    }
} 
	if (contadorperfeito == n1)
		printf("n1 %d\n", n1);

  printf("perfeito %d\n", contadorperfeito);
	for (b = 1; b <= n1; b++){
		for (contadortriangular = 3;contadortriangular<=n1;contadortriangular++){
			tr1=contadortriangular-1;
			tr2=contadortriangular-2;
				if((contadortriangular*tr2*tr1)==b){
					printf("b %d\n", b);
}	

}
}


	return 0;
}