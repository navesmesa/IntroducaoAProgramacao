/* ================================================================== *
 *  Universidade Federal de São Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 06 - Exercício 03 - Boxplot
 *
 *  Instruções
 *  ----------
 *
 *  Este arquivo contém o código que auxiliará no desenvolvimento do
 *  exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *  Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */
#include <stdio.h>

/* <<< COMPLETE AQUI >>> */

int main(){

    int num, x, y, troca;
    float mediana = 0, q1 = 0, q3 = 0, inf = 10000, sup = 0;
    scanf("%d", &num);  
    int valores[num],menor[num], maior[num];
    for(x=0;x<num;x++){
      scanf("%d", &valores[x]);
    }
    for(x = 0; x < num - 1; x++){       
        for(y = 0; y < num - x - 1; y++){          
            if(valores[y] > valores[y + 1]){               
                troca = valores[y];
                valores[y] = valores[y + 1];
                valores[y + 1] = troca;
            }
        }
    }
   if (num%2!=0){
     mediana = (float)valores[num/2];
   }
  else if (num%2==0){
    mediana = ((float)(valores[num/2] + valores[(num/2)-1]))/2;
  }
  for (x = 0; x<num/2;x++){
    menor[x] = valores[x];
  }
  for (x=num-1, y = 0;x>=num/2;x--, y++){
    maior[y] = valores[x];
  }

  if ((num/2)%2!=0){
     q1 = (float)menor[num/4];
     q3 = (float)maior[num/4];
   }
  else if ((num/2)%2==0){
    q1 = ((float)(menor[num/4] + menor[(num/4)-1]))/2;
    q3 = ((float)(maior[num/4] + maior[(num/4)-1]))/2;
  }
  for(x = 0; x < num/2; x++){
    if (menor[x]<inf){
      inf = menor[x];
    }
    if (maior[x]>sup){
      sup = maior[x];
    }
    }
  
   printf("%.2f\n", inf);
   printf("%.2f\n", q1);
   printf("%.2f\n", mediana);
   printf("%.2f\n", q3);
   printf("%.2f\n", sup);
  
    return 0;
}