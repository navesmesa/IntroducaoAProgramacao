/* ================================================================== *
 *  Universidade Federal de Sao Carlos - UFSCar, Sorocaba
 *
 *  Disciplina: Introdução à Programação
 *  Prof. Tiago A. Almeida
 *
 *  Lista 08 - Exercício 03 - Retas
 *
 *  Instruções
 *  ----------
 *
 *	Este arquivo contém o código que auxiliará no desenvolvimento do
 *	exercício. Você precisará completar as partes requisitadas.
 *
 * ================================================================== *
 *	Dados do aluno:
 *
 *  RA: 814149
 *  Nome: João Vitor Naves Mesa
 *
 * ================================================================== */

#include <stdio.h>
#include <math.h>

typedef struct ponto{
  int x;
  int y;
}  PONTO;

int main(){
  PONTO A, B, C, D;
  double m1, m2, d1, d2, a, b, c, d, e, f, Iy, Ix;

  //Reta 1: BA, reta 2: DC

  scanf("%d %d", &A.x, &A.y);
  scanf("%d %d", &B.x, &B.y);
  scanf("%d %d", &C.x, &C.y);
  scanf("%d %d", &D.x, &D.y);

  m1 = (float) (B.y - A.y)/(B.x - A.x);
  m2 = (float) (D.y - C.y)/(D.x - C.x);

  if ((B.x - A.x) != 0){
    printf("%.2f ", m1);  
  }
  else{
    printf("indefinido ");
  }
  if ((D.x - C.x) != 0){
    printf("%.2f\n", m2);  
  }
  else{
    printf("indefinido\n");
  }
    
  d1 = ((B.x - A.x) * (B.x - A.x)) + ((B.y-A.y) * (B.y - A.y));
  d1 = sqrt(d1);

  printf("%.2f ", d1);
  
  d2 = ((D.x - C.x) * (D.x - C.x)) + ((D.y-C.y) * (D.y - C.y));
  d2 = sqrt(d2);

  printf("%.2f\n", d2);

  if (m1 == m2){
    return 0;
  }
  else{
    a = (B.x - A.x);
    b = (B.y-A.y);
    c = (A.y * B.x) - (B.y * A.x);
    d = (D.x - C.x);
    e = (D.y-C.y);
    f = (C.y * D.x) - (D.y * C.x);

    Iy = (a * f - d * c)/(a*e - d*b);
    Ix = (c - b * Iy)/a;

    printf("%.2lf %.2lf\n", Iy*-1, Ix);
    
    
    } 
  
  

  return 0;
}