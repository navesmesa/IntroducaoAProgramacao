#include <stdio.h>

typedef struct data{
  int dia;
  int mes;
  int ano;
} Data;


int main(){
  Data data;
  int A, B, C, D, valor;

  scanf("%d/%d/%d", &data.dia, &data.mes, &data.ano);

  printf("%d/%d/%d\n", data.dia, data.mes, data.ano);

  D = data.ano - 1900;

  printf("%d\n", D);

  
}